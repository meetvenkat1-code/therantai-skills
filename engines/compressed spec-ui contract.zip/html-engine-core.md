# html-engine-core (UI + Hybrid + Model Core v2 + Catalog Panel v3.2, Mode A)

## Law
- One standalone `.html`; all CSS/JS inline; no CDN, no `<form>`, no frameworks; streaming on every call; <200KB.
- Hybrid: Claude Native in claude.ai (no key, no Authorization header, hardcoded branch); standalone = config providers. Native is never a lane.
- Priority: project prompt > UI Contract > memory. Conflict -> flag, ask.
- Identity line in system prompt: `This engine [verb]s [what] so that [who] can [transformation].`
- Build order: clarify -> contracts -> system prompt -> HTML (CSS, Core, drawer, picker, logic, errors) -> maker's mark check.

## Layout
- Sandwich: fixed header 48px / scrolling `.out` (`top:48;bottom:inputH`) / fixed input bar. `body{margin:0;overflow:hidden}`. No footer.
- Header: **A** name + `Config: Live|Local Fallback` badge | **B** `☰`(if library) lane button (dot inside) `▤`(if library) `⚙` + Copy All | **C** far right, stacked: `<i>crafted by</i>` / `meet.venkat1@gmail.com` mailto, .72rem muted, lowercase.
- `window.EnginePanels={library,importExport,settings}`; no markup for false flags. Overlay panels: fixed, `translateX(±100%)`->0, 0.25s, own backdrop+toggle, ID-level open rule `#id.open{transform:translateX(0)}`.
- Gear drawer: right, `top:48;bottom:0;width:320px` (catalog drawers 400px, max 92%). Order: Lanes, Model catalog, Keys, engine settings. Save -> "✓ Saved" 1.5s -> close.
- Output width 80-90%, no `max-width`/`62ch`, padding <=1.5rem, `word-break:break-word`.
- Never `display:none` on event-wired elements (use `visibility`+`pointer-events`); no `position:sticky` in scroll containers.

## Palette
`--bg-void #0a0a0f --bg-surface #12121a --bg-elevated #1a1a28 --bg-border #2a2a3d --text-primary #e8e8f0 --text-secondary #9090a8 --text-muted #505068 --accent-main #7c6ef5 --accent-glow rgba(124,110,245,.15) --amber #f5a623 --green #4caf82 --coral #f56565 --teal #38bdf8 --orange-warn #f97316`

## Render / copy
- Markdown via `innerHTML`+parser (escape `&<>` first), re-render accumulated text per chunk; never `textContent`.
- One `copyToClipboard(text,btn)`: clipboard API -> `<textarea>` execCommand fallback -> `✗ Failed`. No IS_ARTIFACT branch, no div selection, no prompt().
- Copy All: top-positioned, reads live DOM (`innerText`), divider `\n\n— Stage 01: [Name] —\n\n`; never gated on `lastResults`. Per-card copy additive, direct child of card header.

## Storage / persistence
- `storageSet/Get/Remove/List` wrap storage; artifacts use `window.storage`; standalone localStorage first, folder-connect only additive. Keys only via `getKey/setKey` at `hek_{keyStorageName}`.

## Model Core
- `model.json` @ `CANONICAL_CONFIG_URL` (therantai-config/main): `{native_model, defaultLanes:["pid::slug"], model_aliases:{}, providers:[{id,native,label,dotColor,requiresKey,keyStorageName,keyLabel,keyPlaceholder,keyNote,standaloneOnly,defaultFor:[],endpoint,authHeader,authPrefix,extraHeaders,requestFormat:"openai-chat",streamFormat,modelChain,softFallback,hardFallback,timeoutMs,idleMs}]}`.
- Floor (`LOCAL_FALLBACK_CONFIG`): claude (artifact) + groq `openai/gpt-oss-120b`->`gpt-oss-20b` (idle 3s/15s) + or-auto `openrouter/free` (9s/45s, standaloneOnly). Never `openrouter/auto`.
- Boot: render floor, then `fetchModelConfig` (cache-busted, `isValidConfig`: <=1 native, >=1 usable). No provider/slug/endpoint/timing literals in HTML; no `DOT_COLORS`, `OR_MODEL_MAP`, local `readStream`.
- `callModel`: curated `{provider,system,user,onText,validate}` (chain + fallbacks) | strict `{provider,model,...}` (exact model, no fall-through). 429 retry once (1800ms); 400 system-role fold; 401/402/403/413 fatal; 404 hint; empty-reply error; served tag; reasoning deltas = alive; errors carry `status`,`retryAfter`; `signal` aborts.
- Stream finalize four-layer: terminator (`[DONE]`/`event: message_stop`), `done` flag, idle timer, hard ceiling.
- Multi-call on Claude Native: sequential, never `Promise.all`.
- Thin wrapper (curated, single-provider engines):
```js
async function callAI(sys,user,onChunk){var prev=0;await callModel({provider:getSelectedProvider(),system:sys,user:user,
 onText:function(acc){if(acc.length<prev)prev=0;onChunk(acc.slice(prev));prev=acc.length}})}
```

## Mode A: Lanes (single path)
- Lane = `providerId::modelId`. Lanes = `defaultLanes()` + pins (`customLanes[{key,provider,model}]`). Untouched (`lanesTouched=false`): only first default ticked; cleared stays cleared. `MAX_LANES=12`.
- One Run button, no provider dropdown; header lane button (`laneTxt`, dot of first active lane). Parallel, 220ms stagger, strict `callModel`; honest labels (`served: X` when different); failures stay in their own column; cut -> flag.
- Catalog: `GET endpoint.replace(/chat\/completions$/,'/models')` via `catalogHeaders` (OpenRouter none; keyed = auth header only); one in-flight per provider; tab switches before fetch; cached; user-refreshed; untrusted text via `textContent`. Tiers free/cheap/medium/premium/n/a; search + `/regex/`; cap 150; Pinned chip; auto-fetch only public/keyed.
- Aliases: `resolveModelId` only against a fetched catalog, never cross-provider. Migrate old lane keys to `pid::model`.
- Drawer ids: laneCount, laneList, provBtns, catSearch, tierChips, catRows, catStatus, keyFields, saveKeysBtn, clearKeysBtn. Clear keys removes `hek_` + legacy slots.
- Optional modules (tags, Synth Picks, price sort): off unless asked.

## Artifact notes
Inside claude.ai only Native routes (no lanes); `standaloneOnly` blocked at run. Published pages block other hosts, so engines ship as downloadable files.
